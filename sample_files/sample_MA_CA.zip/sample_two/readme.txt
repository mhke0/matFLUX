README

This folder contains two example .mat data files and one .mat correction file.

Contents:
1. Matrix.mat
2. Capsid.mat
4. Two Folders with Bead Data (MA, CA)

For Testing:
1. Load Matrix.mat as your first file.
2. The software can now be tested for one-color processing and analysis.

For Alignment:
1. Select the parent folder of the bead data(here 'samlpe_files'. 
   - This will create the Correction and automatically suggest the missing file in the "Multicolor" tab.
2. Load the missing file(s) in the "Multicolor" tab.
3. Manual Alignment can be performed at any time.